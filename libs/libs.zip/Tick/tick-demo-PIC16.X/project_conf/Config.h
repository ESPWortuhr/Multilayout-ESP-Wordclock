#ifndef CONFIG_H
#define CONFIG_H
/**
* Configures here the processor speed
*/
#define CONFIG_TIMING_MAIN_CLOCK 1000000
#endif
// End of Header file
